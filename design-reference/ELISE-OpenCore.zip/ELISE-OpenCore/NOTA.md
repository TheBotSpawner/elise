# ELISE — Open Core · Nota de uso

## Concepto
Una esfera de vidrio finísima que funciona como un ojo. Las dos medias lunas del logo son los párpados: abrazan la esfera sin cerrarla y se abren, se entrecierran o parpadean. El núcleo es la pupila, la presencia de ELISE: mira, se dilata con la voz y se contrae cuando algo pide atención. El movimiento dice el estado; el color solo lo confirma.

**Precauciones del ojo.** Un ojo que te mira todo el tiempo incomoda, así que la pupila sigue al puntero apenas (14 % del radio), nunca en sentido fijo, y no parpadea: un parpadeo automático se siente más humano de lo que conviene. No hay rojo intenso ni pupila roja: el error es coral, al 50 %, y se lee por la forma (párpados entrecerrados y pupila hueca), para alejarse de las referencias a "ojo vigilante" de la ciencia ficción. Los párpados nunca forman un anillo completo y se mueven siempre junto con la esfera: con el puntero solo mira la pupila y el ojo entero se corre un 3 % del radio.

## Colores

| Rol | Oscuro | Claro |
|---|---|---|
| Fondo de referencia | `#050B0F` | `#F6F8F9` |
| Acento / energía | `#22D3EE` | `#22D3EE` (solo núcleo y halos) |
| Párpados | degradé `#B4F7FC → #22D3EE → #0FA7C0` | degradé `#0E8597 → #0A6573` + filo de 1 px |
| Pupila | `#9EF6FD` con halo aditivo | `#22D3EE` con anillo `#0A6573` |
| Borde de la esfera | blanco-cyan al 20 % | `#0A6573` al 26 % |
| Texto / monocromo | `#FFFFFF` | `#0B1A20` |

En claro el cyan puro no tiene contraste suficiente sobre blanco (1,7:1). Por eso los párpados usan el acento mezclado con tinta (`#0A6573`, 6,3:1), el borde de la esfera es un trazo oscuro y el brillo queda como un detalle, nunca como la señal. En el Orb, el color en claro se deriva solo del `accent`.

Tintes de confirmación (se mezclan con el acento, nunca lo reemplazan): success `#4BE3B0` 38 % · attention `#F6B44E` 40 % · error `#FF6A5C` 50 % · waiting_approval `#A9C7FF` 22 % · sleeping `#8A9BA3` 55 %.

## Tiempos
Transiciones continuas entre cualquier par de estados: movimiento ~450 ms (τ 150 ms), color ~600 ms (τ 200 ms), puntero ~400 ms (τ 133 ms). Los párpados nunca bajan de 142° y la forma de ojo se mantiene en todos los estados.

| Estado | Firma (se lee en gris) | Ritmo |
|---|---|---|
| idle | párpados en diagonal (como el logo), pupila al centro | respira cada 5,5 s (±1,2 %), deriva de ±3° cada 12 s |
| listening | ojo horizontal bien abierto: los párpados se separan de la esfera | respira cada 2,8 s |
| user_speaking | ojo horizontal; con la voz de la persona los párpados se abren, la pupila se dilata y la luz entra desde el borde del vidrio (lo inverso de speaking) | sigue el nivel (ataque 45 ms, caída 160 ms) |
| thinking | párpados entornados; la pupila mira arriba a la derecha y da vueltas lentas | un giro de la mirada cada 3,2 s |
| searching | ojo horizontal abierto; la pupila salta de un punto a otro, mirando para todos lados | salto de 130 ms, pausa de 620 ms |
| speaking | párpados en diagonal; el ojo se ilumina desde la pupila con la voz de ELISE: la pupila late, la luz llena el vidrio y los párpados se abren apenas | sigue el nivel (ataque 45 ms, caída 160 ms) |
| executing | ojo concentrado, almendrado; un iris de dos segmentos gira alrededor de la pupila | una vuelta cada 1,3 s |
| waiting_approval | párpados a los costados, casi cerrados, quietos; anillo fijo alrededor de la pupila | el anillo late cada 2,4 s |
| success | el ojo se abre y la pupila se dilata + un "sí" vertical | 900 ms → idle |
| attention | ojo muy abierto, pupila contraída + pulso que sale hacia afuera | un pulso cada 1,6 s |
| error | ojo entrecerrado en diagonal, pupila hueca + un "no" horizontal | 1200 ms → idle apagado (60 %) hasta el próximo estado |
| sleeping | ojo cerrado: solo queda una rendija con la pupila tenue | respira cada 8 s |

**Boot (2,6 s):** pupila (0–600 ms) → la esfera se dibuja (600–1400 ms) → entran los párpados (1200–2100 ms). Con reduced motion: fundido de 350 ms.

**Reduced motion:** sin respiración, deriva ni gestos. La pupila de searching salta cada 2,2 s, el iris y el pulso quedan fijos. El nivel de audio sigue moviendo el ojo al 50 %, porque es información y no decoración.

## Tamaños

| Uso | Tamaño | Detalle |
|---|---|---|
| Héroe | 220–620 px | todo: vidrio, reflejo, glow de 3 pasadas |
| Panel / widget | 64–220 px | vidrio, glow de 2 pasadas |
| Navegación | 28–63 px | sin relleno de vidrio ni reflejo; párpados 30 % más gruesos, pupila más grande, anillo fijo en attention |

## Logo
- **Símbolo:** dos medias lunas planas y un núcleo. El Orb usa exactamente esa forma como párpados: el logo es el ojo en reposo, plano; el Orb es el mismo ojo de vidrio y vivo.
- **Versiones:** `color` (fondos oscuros), `color-onlight` (fondos claros), `mono-light` (blanco), `mono-dark` (`#0B1A20`).
- **Geometrías:** `full` desde 64 px, `small` de 24 a 64 px, `micro` para 16 px (favicon y bandeja).
- **Área de respeto:** el radio del núcleo × 3 alrededor del símbolo; en los lockups, la altura de la E.
- **Mínimos:** símbolo de 16 px; lockup horizontal de 96 px de ancho; wordmark solo de 64 px de ancho.
- **Ícono de app:** símbolo al 60 % del lado, dentro del círculo inscripto; funciona con máscaras redondas y squircle.
- **Bandeja:** `tray-template` es negro con alfa (template de macOS, el sistema lo invierte); `tray-light` es blanco para barras oscuras de Windows y Linux.

## No
Glow como única señal en claro · cambiar de estado solo por color · párpados cerrados en un anillo completo · parpadeos automáticos · pupila roja o mirada fija que sigue al usuario · anillos concéntricos, marcas de escala o retículas · estirar el wordmark o cambiarle el espaciado.
