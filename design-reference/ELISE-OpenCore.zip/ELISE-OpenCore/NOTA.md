# ELISE — Open Core · Nota de uso

## Concepto
Una esfera de vidrio finísima, dos arcos opuestos que la abrazan sin cerrarla, un flujo en S que la cruza (el diálogo) y un núcleo pequeño (la presencia). El movimiento dice el estado; el color solo lo confirma.

## Colores

| Rol | Oscuro | Claro |
|---|---|---|
| Fondo de referencia | `#050B0F` | `#F6F8F9` |
| Acento / energía | `#22D3EE` | `#22D3EE` (solo núcleo y halos) |
| Arcos | degradé `#B4F7FC → #22D3EE → #0FA7C0` | degradé `#0E8597 → #0A6573` + filo de 1 px |
| Núcleo | `#9EF6FD` con halo aditivo | `#22D3EE` con anillo `#0A6573` |
| Borde de la esfera | blanco-cyan al 20 % | `#0A6573` al 26 % |
| Texto / monocromo | `#FFFFFF` | `#0B1A20` |

En claro el cyan puro no tiene contraste suficiente sobre blanco (1,7:1). Por eso los arcos usan el acento mezclado con tinta (`#0A6573`, 6,3:1), el borde de la esfera es un trazo oscuro y el brillo queda como un detalle, nunca como la señal. En el Orb, el color en claro se deriva solo del `accent`.

Tintes de confirmación (se mezclan con el acento, nunca lo reemplazan): success `#4BE3B0` 38 % · attention `#F6B44E` 40 % · error `#FF6A5C` 55 % · waiting_approval `#A9C7FF` 22 % · sleeping `#8A9BA3` 55 %.

## Tiempos
Transiciones continuas entre cualquier par de estados: movimiento ~450 ms (τ 150 ms), color ~600 ms (τ 200 ms), puntero ~400 ms (τ 133 ms). Los giros se frenan hacia un múltiplo de 180°, así que los arcos nunca saltan.

| Estado | Firma (se lee en gris) | Ritmo |
|---|---|---|
| idle | arcos en diagonal, 128°, respiración mínima | respira cada 5,5 s (±1,2 %), deriva de ±4° cada 11 s |
| listening | arcos a los lados, abiertos hacia afuera ( ) | respira cada 2,8 s |
| user_speaking | arcos laterales cortos y gruesos que se abren con la voz de la persona; flujo hacia el núcleo | sigue el nivel (ataque 45 ms, caída 160 ms) |
| thinking | arcos cortos girando; la S se reorganiza | giro de 42°/s, la S gira a 70°/s |
| searching | arcos arriba y abajo + meridiano que barre la esfera | ida y vuelta cada 2,2 s |
| speaking | núcleo y S se amplían con la voz de ELISE; flujo hacia afuera | sigue el nivel |
| executing | arcos orbitando + satélite con estela | 150°/s · satélite 1,1 s/vuelta |
| waiting_approval | arcos laterales casi cerrados, quietos; anillo alrededor del núcleo | anillo late cada 2,4 s |
| success | los arcos casi cierran el círculo + un "sí" vertical | 900 ms → idle |
| attention | anillo tenue + pulso que sale hacia afuera | un pulso cada 1,6 s |
| error | arcos se contraen a 44°, núcleo hueco + un "no" horizontal | 1200 ms → idle apagado (60 %) hasta el próximo estado |
| sleeping | esfera más chica, todo al 38 %, sin flujo | respira cada 8 s |

**Boot (2,6 s):** núcleo (0–600 ms) → la esfera se dibuja (600–1400 ms) → entran los arcos (1200–2100 ms) → aparece la S. Con reduced motion: fundido de 350 ms.

**Reduced motion:** sin giros, respiración ni gestos; el barrido, el satélite y el pulso quedan como marcas fijas. El nivel de audio sigue moviendo el Orb al 50 %, porque es información y no decoración.

## Tamaños

| Uso | Tamaño | Detalle |
|---|---|---|
| Héroe | 220–620 px | todo: vidrio, reflejo, glow de 3 pasadas, estelas |
| Panel / widget | 64–220 px | vidrio, glow de 2 pasadas |
| Navegación | 28–63 px | sin relleno de vidrio ni estelas; arcos 30 % más gruesos, núcleo más grande, puntas romas |

## Logo
- **Símbolo:** dos medias lunas planas y un núcleo. Es plano y circular (el Orb es de vidrio y con perspectiva); conviven sin ser una copia.
- **Versiones:** `color` (fondos oscuros), `color-onlight` (fondos claros), `mono-light` (blanco), `mono-dark` (`#0B1A20`).
- **Geometrías:** `full` desde 64 px, `small` de 24 a 64 px, `micro` para 16 px (favicon y bandeja).
- **Área de respeto:** el radio del núcleo × 3 alrededor del símbolo; en los lockups, la altura de la E.
- **Mínimos:** símbolo de 16 px; lockup horizontal de 96 px de ancho; wordmark solo de 64 px de ancho.
- **Ícono de app:** símbolo al 60 % del lado, dentro del círculo inscripto; funciona con máscaras redondas y squircle.
- **Bandeja:** `tray-template` es negro con alfa (template de macOS, el sistema lo invierte); `tray-light` es blanco para barras oscuras de Windows y Linux.

## No
Glow como única señal en claro · cambiar de estado solo por color · arcos cerrados en un anillo completo (excepto el instante de success) · anillos concéntricos, marcas de escala o retículas · estirar el wordmark o cambiarle el espaciado.
