/*!
 * ELISE Orb — "Open Core"
 * Canvas 2D puro. Sin WebGL, sin librerías, sin imágenes, sin DOM propio.
 *
 * Uso:
 *   const orb = new EliseOrb();
 *   function frame(now) {
 *     ctx.clearRect(0, 0, w, h);
 *     orb.draw(ctx, cx, cy, size, {
 *       state: 'idle', light: false, accent: '#22D3EE', reduced: false,
 *       level: 0, pointer: { x: 0, y: 0 }, boot: null
 *     }, now);
 *     requestAnimationFrame(frame);
 *   }
 *
 * - ctx: CanvasRenderingContext2D ya escalado por devicePixelRatio (el Orb dibuja en px CSS).
 * - size: lado del cuadrado que ocupa el Orb (px CSS). El Orb se centra en (cx, cy).
 * - now: tiempo en ms (performance.now() o el timestamp de requestAnimationFrame).
 * - input.level: 0..1 en tiempo real. Si es negativo, el Orb simula una voz.
 * - input.boot: null, o { t: ms transcurridos desde que empezó el arranque }.
 *   Duración: EliseOrb.bootDuration(reduced) → 2600 ms (o 350 ms con reduced motion).
 *
 * Lecturas útiles después de draw():
 *   orb.effectiveState  → estado que se está mostrando (success/error vuelven solos a idle)
 *   orb.suggestedFps    → 60 en estados activos, 30 en reposo, 20 dormida/reduced
 */
(function (root) {
  'use strict';

  /* ───────────────────────── Tabla de estados ─────────────────────────
   * Todo lo ajustable vive acá. El código de dibujo solo lee estos valores.
   *
   * Geometría (R = radio de la esfera)
   *   scale     tamaño de la esfera (1 = base)
   *   rot       orientación de los arcos en grados (-38 diagonal, 90 laterales, 0 arriba/abajo)
   *   span      apertura angular de cada arco (°). 180 = esfera cerrada
   *   arcW      grosor máximo del arco (× R)
   *   arcOut    separación radial de los arcos (× R) → "se abre"
   *   squash    perspectiva de los arcos (1 = círculo plano)
   * Movimiento
   *   spin      giro continuo de los arcos (°/s)
   *   wobble    oscilación lenta de los arcos (°) · wobbleP período (s)
   *   breath    respiración de escala (fracción) · breathP período (s)
   * Flujo interno en S
   *   flow      opacidad · flowAmp curvatura · flowSpeed ciclos/s (+ hacia afuera, − hacia el núcleo)
   *   flowTurn  giro de la S (°/s) · flowMorph cuánto se reorganiza su curvatura
   * Núcleo
   *   core      radio (× R) · glow brillo del halo
   *   hollow    0..1 núcleo hueco (error) · halo 0..1 anillo de espera alrededor del núcleo
   * Señales
   *   sweep     barrido meridiano (searching) · sat satélite en órbita (executing)
   *   ping      pulso que sale hacia afuera (attention)
   *   shake / nod  gesto de "no" / "sí" al entrar al estado
   * Audio
   *   lvArcs    el nivel abre los arcos · lvCore el nivel agranda el núcleo
   *   lvFlow    el nivel amplía la S · lvArcW el nivel engrosa los arcos
   * Color
   *   bright    intensidad global 0..1
   *   tint      [color, cantidad] que confirma el estado (nunca es la única señal)
   *   dur       ms; los estados con duración vuelven a idle solos
   */
  const STATES = {
    idle: {
      scale: 1, rot: -38, span: 128, arcW: 0.2, arcOut: 0, squash: 0.84,
      spin: 0, wobble: 4, wobbleP: 11, breath: 0.012, breathP: 5.5,
      flow: 0.32, flowAmp: 0.28, flowSpeed: 0.1, flowTurn: 0, flowMorph: 0,
      core: 0.12, glow: 0.8, hollow: 0, halo: 0,
      sweep: 0, sat: 0, ping: 0, shake: 0, nod: 0,
      lvArcs: 0, lvCore: 0, lvFlow: 0, lvArcW: 0,
      bright: 0.88, tint: [null, 0]
    },
    listening: {
      scale: 1.04, rot: 90, span: 104, arcW: 0.15, arcOut: 0.15, squash: 0.9,
      wobble: 2, wobbleP: 6, breath: 0.022, breathP: 2.8,
      flow: 0.2, flowAmp: 0.16, flowSpeed: -0.15,
      core: 0.13, glow: 0.95, bright: 1
    },
    user_speaking: {
      scale: 1.02, rot: 90, span: 64, arcW: 0.27, arcOut: 0.0, squash: 0.9,
      wobble: 0, breath: 0,
      flow: 0.28, flowAmp: 0.18, flowSpeed: -0.7,
      core: 0.12, glow: 1, lvArcs: 0.34, lvCore: 0.45, lvFlow: 0.4, lvArcW: 0.25,
      bright: 1
    },
    thinking: {
      rot: -38, span: 70, arcW: 0.21, spin: 42, wobble: 0, breath: 0.006, breathP: 2,
      flow: 0.95, flowAmp: 0.42, flowSpeed: 0.35, flowTurn: 70, flowMorph: 0.75,
      core: 0.1, glow: 0.75, bright: 0.95
    },
    searching: {
      rot: 0, span: 112, arcW: 0.14, squash: 0.8, wobble: 0,
      flow: 0.12, flowAmp: 0.12,
      core: 0.1, glow: 0.7, sweep: 1, bright: 0.9
    },
    speaking: {
      rot: -38, span: 120, arcW: 0.2, wobble: 3, wobbleP: 4,
      flow: 0.72, flowAmp: 0.26, flowSpeed: 0.8,
      core: 0.14, glow: 1, lvCore: 0.95, lvFlow: 1.1, lvArcW: 0.35, bright: 1
    },
    executing: {
      rot: 22, span: 84, arcW: 0.2, spin: 150, wobble: 0,
      flow: 0.45, flowAmp: 0.22, flowSpeed: 1.2,
      core: 0.11, glow: 0.9, sat: 1, bright: 1
    },
    waiting_approval: {
      rot: 90, span: 150, arcW: 0.16, arcOut: 0.02, wobble: 0, breath: 0.004, breathP: 3,
      flow: 0.1, flowAmp: 0.1, flowSpeed: 0.05,
      core: 0.11, glow: 0.85, halo: 1, bright: 0.95, tint: ['#A9C7FF', 0.22]
    },
    success: {
      rot: -38, span: 172, arcW: 0.17, wobble: 0,
      flow: 0.3, core: 0.17, glow: 1.2, nod: 1, bright: 1,
      tint: ['#4BE3B0', 0.38], dur: 900
    },
    attention: {
      rot: -38, span: 128, arcOut: 0.06, wobble: 0,
      core: 0.14, glow: 1, ping: 1, bright: 1, tint: ['#F6B44E', 0.4]
    },
    error: {
      rot: -38, span: 44, arcW: 0.2, arcOut: -0.02, wobble: 0, breath: 0,
      flow: 0.06, core: 0.13, glow: 0.5, hollow: 1, shake: 1, bright: 0.95,
      tint: ['#FF6A5C', 0.55], dur: 1200
    },
    sleeping: {
      scale: 0.9, rot: -38, span: 158, arcW: 0.1, squash: 0.8, wobble: 0,
      breath: 0.03, breathP: 8,
      flow: 0, core: 0.07, glow: 0.3, bright: 0.38, tint: ['#8A9BA3', 0.55]
    }
  };
  // Cada estado hereda de idle lo que no define.
  for (const k in STATES) if (k !== 'idle') STATES[k] = Object.assign({}, STATES.idle, STATES[k]);

  /* Ajustes que no dependen del estado */
  const CONFIG = {
    accent: '#22D3EE',
    tauMotion: 150,   // ms · ~95 % en 450 ms
    tauColor: 200,    // ms · ~95 % en 600 ms
    tauPointer: 133,  // ms · ~95 % en 400 ms
    afterErrorDim: { bright: 0.6, tint: ['#8A9BA3', 0.3] }, // idle "apagado" tras un error
    reduced: { motion: 0, flowSpeed: 0.15, level: 0.5 },     // reduced-motion
    boot: { dot: 600, sphere: 800, arcs: 900, total: 2600, reduced: 350 },
    pointerLean: 0.07,  // cuánto se inclina hacia el puntero (× R)
    periods: { ping: 1.6, sweep: 2.2, sat: 1.1, halo: 2.4 }
  };

  const NUM_KEYS = Object.keys(STATES.idle).filter(k => typeof STATES.idle[k] === 'number');
  const TAU = Math.PI * 2, DEG = Math.PI / 180;

  /* ── color ── */
  const _hexCache = {};
  function hex(c) {
    if (_hexCache[c]) return _hexCache[c];
    let s = String(c).trim().replace('#', '');
    if (s.length === 3) s = s.split('').map(x => x + x).join('');
    const n = parseInt(s.slice(0, 6), 16);
    const out = isNaN(n) ? [34, 211, 238] : [(n >> 16) & 255, (n >> 8) & 255, n & 255];
    return (_hexCache[c] = out);
  }
  const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
  const rgba = (c, a) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a < 0 ? 0 : a > 1 ? 1 : +a.toFixed(3)})`;
  const WHITE = [255, 255, 255], INK = [5, 50, 61], INK_DEEP = [2, 28, 34], NIGHT = [0, 59, 74];

  const clamp = (x, a, b) => (x < a ? a : x > b ? b : x);
  const ease = t => (t <= 0 ? 0 : t >= 1 ? 1 : t * t * (3 - 2 * t));
  const easeOut = t => 1 - Math.pow(1 - clamp(t, 0, 1), 3);

  class EliseOrb {
    constructor(options) {
      this.states = (options && options.states) || STATES;
      this.config = Object.assign({}, CONFIG, options && options.config);
      this.p = Object.assign({}, this.states.idle);  // valores suavizados
      this.color = hex(this.config.accent).slice();
      this.ptr = { x: 0, y: 0 };
      this.level = 0;
      this.t = 0;              // reloj interno (s)
      this.last = null;
      this.spinPhase = 0;
      this.flowPhase = 0;
      this.flowRot = 0;
      this.inState = null;
      this.stateStart = 0;
      this.dimAfterError = false;
      this.effectiveState = 'idle';
      this.suggestedFps = 60;
      this._first = true;
    }

    static bootDuration(reduced) { return reduced ? CONFIG.boot.reduced : CONFIG.boot.total; }
    static get STATES() { return STATES; }
    static get CONFIG() { return CONFIG; }

    /* ───────────── lógica: estado → objetivos suavizados ───────────── */
    _update(input, now) {
      const dtMs = this.last == null ? 16 : clamp(now - this.last, 0, 100);
      this.last = now;
      const dt = dtMs / 1000;
      this.t += dt;

      const req = this.states[input.state] ? input.state : 'idle';
      if (req !== this.inState) {
        this.dimAfterError = false;
        this.inState = req;
        this.stateStart = now;
      }
      let eff = req;
      const def = this.states[req];
      const since = now - this.stateStart;
      if (def.dur && since > def.dur) {
        eff = 'idle';
        if (req === 'error') this.dimAfterError = true;
      }
      this.effectiveState = eff;
      this.stateElapsed = since;

      const target = Object.assign({}, this.states[eff]);
      if (eff === 'idle' && this.dimAfterError) {
        target.bright = this.config.afterErrorDim.bright;
        target.tint = this.config.afterErrorDim.tint;
      }
      const reduced = !!input.reduced;
      if (reduced) {
        const r = this.config.reduced;
        target.spin *= r.motion; target.wobble *= r.motion; target.breath *= r.motion;
        target.flowTurn *= r.motion; target.flowMorph *= r.motion;
        target.flowSpeed *= r.flowSpeed;
        target.shake = 0; target.nod = 0;
      }

      // Primer cuadro: sin transición
      const kM = this._first ? 1 : 1 - Math.exp(-dtMs / this.config.tauMotion);
      const kC = this._first ? 1 : 1 - Math.exp(-dtMs / this.config.tauColor);
      const kP = this._first ? 1 : 1 - Math.exp(-dtMs / this.config.tauPointer);
      this._first = false;

      for (const k of NUM_KEYS) this.p[k] += (target[k] - this.p[k]) * kM;
      // gestos: se disparan al entrar, no se interpolan
      this.p.shake = target.shake; this.p.nod = target.nod;

      // color: acento + tinte del estado
      const acc = hex(input.accent || this.config.accent);
      const tc = target.tint && target.tint[0] ? mix(acc, hex(target.tint[0]), target.tint[1]) : acc;
      this.color = mix(this.color, tc, kC);

      // puntero
      const px = input.pointer ? clamp(+input.pointer.x || 0, -1, 1) : 0;
      const py = input.pointer ? clamp(+input.pointer.y || 0, -1, 1) : 0;
      const pm = reduced ? 0.3 : 1;
      this.ptr.x += (px * pm - this.ptr.x) * kP;
      this.ptr.y += (py * pm - this.ptr.y) * kP;

      // audio: real o simulado; ataque rápido, caída suave
      let lv = typeof input.level === 'number' ? input.level : 0;
      if (lv < 0) lv = this._simLevel(this.t);
      lv = clamp(lv, 0, 1);
      const kL = 1 - Math.exp(-dtMs / (lv > this.level ? 45 : 160));
      this.level += (lv - this.level) * kL;

      // giro continuo; al frenar, vuelve al múltiplo de 180° más cercano (los arcos son simétricos)
      const p = this.p;
      this.spinPhase += p.spin * DEG * dt;
      if (Math.abs(p.spin) < 6) {
        const home = Math.round(this.spinPhase / Math.PI) * Math.PI;
        this.spinPhase += (home - this.spinPhase) * kM * (1 - Math.abs(p.spin) / 6);
      }
      this.flowPhase += p.flowSpeed * dt;
      this.flowRot += p.flowTurn * DEG * dt;
      if (Math.abs(p.flowTurn) < 4) {
        const home = Math.round(this.flowRot / Math.PI) * Math.PI;
        this.flowRot += (home - this.flowRot) * kM * 0.5;
      }

      // fps sugeridos para ahorrar en reposo / segundo plano
      const calm = eff === 'idle' || eff === 'waiting_approval';
      this.suggestedFps = eff === 'sleeping' || (reduced && calm) ? 20 : calm || reduced ? 30 : 60;
      return reduced;
    }

    _simLevel(t) {
      // envolvente de sílabas + frases, sin aleatoriedad (determinista)
      const syl = Math.abs(Math.sin(t * 7.1)) * (0.55 + 0.45 * Math.sin(t * 2.3 + 1.1));
      const word = 0.5 + 0.5 * Math.sin(t * 1.27);
      const phrase = Math.sin(t * 0.55) > -0.55 ? 1 : 0.08;
      return clamp((0.15 + syl * 0.85) * (0.45 + 0.55 * word) * phrase, 0, 1);
    }

    /* ───────────────────────────── dibujo ───────────────────────────── */
    draw(ctx, cx, cy, size, input, now) {
      input = input || {};
      const reduced = this._update(input, now == null ? (typeof performance !== 'undefined' ? performance.now() : Date.now()) : now);
      const p = this.p, t = this.t, lv = this.level * (reduced ? this.config.reduced.level : 1);
      const light = !!input.light;
      const lod = size < 64 ? 0 : size < 220 ? 1 : 2;

      // ── arranque ──
      let bDot = 1, bSphere = 1, bArcs = 1, bFlow = 1, bAlpha = 1;
      if (input.boot && typeof input.boot.t === 'number') {
        const b = this.config.boot, bt = input.boot.t;
        if (reduced) {
          bAlpha = ease(bt / b.reduced);
        } else {
          bDot = easeOut(bt / b.dot);
          bSphere = ease((bt - b.dot) / b.sphere);
          bArcs = easeOut((bt - b.dot - b.sphere * 0.75) / b.arcs);
          bFlow = ease((bt - b.total + 500) / 500);
        }
      }

      // ── paleta ──
      const c = this.color;
      let hi, main, deep;
      if (light) { hi = mix(c, INK, 0.12); main = mix(c, INK, 0.42); deep = mix(c, INK_DEEP, 0.66); }
      else { hi = mix(c, WHITE, 0.62); main = c; deep = mix(c, NIGHT, 0.4); }

      // ── geometría ──
      const breath = 1 + p.breath * Math.sin(t * TAU / Math.max(0.5, p.breathP));
      const R = size * 0.34 * p.scale * breath;
      let ox = 0, oy = 0;
      if (p.shake && !reduced) {
        const s = this.stateElapsed / 1000;
        if (s < 0.9) ox += R * 0.1 * Math.sin(s * TAU * 6.5) * Math.exp(-s * 3.4);
      }
      if (p.nod && !reduced) {
        const s = this.stateElapsed / 1000;
        if (s < 0.8) oy -= R * 0.07 * Math.sin(s * TAU * 2.4) * Math.exp(-s * 4);
      }
      const lean = this.config.pointerLean;
      const X = cx + ox, Y = cy + oy;
      // paralaje: arcos más adelante que el núcleo → inclinación
      const ax = X + this.ptr.x * R * lean, ay = Y + this.ptr.y * R * lean;
      const kx = X + this.ptr.x * R * lean * 0.45, ky = Y + this.ptr.y * R * lean * 0.45;
      const sx = X + this.ptr.x * R * lean * 0.2, sy = Y + this.ptr.y * R * lean * 0.2;

      const wob = p.wobble * DEG * Math.sin(t * TAU / Math.max(0.5, p.wobbleP));
      const rot = p.rot * DEG + this.spinPhase + wob + (1 - bArcs) * -1.6
        + this.ptr.x * 0.12 - this.ptr.y * 0.06;
      // la perspectiva se acentúa hacia el puntero
      const squash = clamp(p.squash - Math.abs(this.ptr.y) * 0.06 + Math.abs(this.ptr.x) * 0.03, 0.55, 1);

      ctx.save();
      ctx.globalAlpha = clamp(p.bright, 0, 1) * bAlpha;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      const px1 = Math.max(1, size / 260); // 1 px lógico mínimo, crece con el tamaño

      // halo ambiente (solo oscuro; en claro el contraste lo da el trazo, no el brillo)
      if (!light && lod > 0 && bSphere > 0) {
        const g = ctx.createRadialGradient(sx, sy, R * 0.2, sx, sy, R * 1.6);
        g.addColorStop(0, rgba(c, 0.10 * p.glow * bSphere));
        g.addColorStop(1, rgba(c, 0));
        ctx.fillStyle = g;
        ctx.fillRect(sx - R * 1.6, sy - R * 1.6, R * 3.2, R * 3.2);
      }

      // pulso hacia afuera (attention)
      if (p.ping > 0.02) {
        const per = this.config.periods.ping;
        const ph = reduced ? 0.45 : (t % per) / per;
        const rr = R * (1.08 + 0.32 * easeOut(ph)) + Math.max(0, p.arcOut) * R;
        const a = (reduced ? 0.55 : Math.pow(1 - ph, 1.4) * 0.75) * p.ping;
        ctx.strokeStyle = rgba(light ? main : hi, a);
        ctx.lineWidth = Math.max(px1 * (lod ? 1.2 : 1.1), R * 0.035 * (reduced ? 0.8 : 1 - ph * 0.6));
        ctx.beginPath(); ctx.arc(sx, sy, rr, 0, TAU); ctx.stroke();
        if (!reduced) { // anillo base tenue: la señal sigue presente entre pulsos (clave a 40 px)
          ctx.strokeStyle = rgba(light ? main : hi, 0.3 * p.ping);
          ctx.lineWidth = Math.max(px1, R * 0.018);
          ctx.beginPath(); ctx.arc(sx, sy, R * 1.12 + Math.max(0, p.arcOut) * R, 0, TAU); ctx.stroke();
        }
        if (!reduced && lod > 0) {
          const ph2 = ((t + per / 2) % per) / per;
          ctx.strokeStyle = rgba(light ? main : hi, Math.pow(1 - ph2, 1.6) * 0.3 * p.ping);
          ctx.beginPath(); ctx.arc(sx, sy, R * (1.08 + 0.32 * easeOut(ph2)), 0, TAU); ctx.stroke();
        }
      }

      // esfera de vidrio
      if (bSphere > 0) {
        if (lod > 0) {
          const g = ctx.createRadialGradient(sx - R * 0.3, sy - R * 0.35, R * 0.1, sx, sy, R);
          if (light) { g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(1, rgba(main, 0.075 * bSphere)); }
          else { g.addColorStop(0, rgba(c, 0.015 * bSphere)); g.addColorStop(0.75, rgba(c, 0.05 * bSphere)); g.addColorStop(1, rgba(c, 0.13 * bSphere)); }
          ctx.fillStyle = g;
          ctx.beginPath(); ctx.arc(sx, sy, R, 0, TAU); ctx.fill();
        }
        ctx.strokeStyle = light ? rgba(deep, (lod ? 0.26 : 0.32) * bSphere) : rgba(hi, (lod ? 0.2 : 0.26) * bSphere);
        ctx.lineWidth = Math.max(lod ? 0.75 : 0.9, R * 0.011);
        ctx.beginPath(); ctx.arc(sx, sy, R, -Math.PI / 2, -Math.PI / 2 + TAU * bSphere); ctx.stroke();
        // reflejo especular fino
        if (lod > 0 && bSphere > 0.5) {
          ctx.strokeStyle = light ? rgba(WHITE, 0.9 * bSphere) : rgba(WHITE, 0.12 * bSphere);
          ctx.lineWidth = Math.max(1, R * (light ? 0.02 : 0.012));
          ctx.beginPath(); ctx.arc(sx, sy, R * 0.9, -2.55, -1.75); ctx.stroke();
        }
      }

      // barrido (searching)
      if (p.sweep > 0.02 && bSphere > 0) {
        ctx.save();
        ctx.beginPath(); ctx.arc(sx, sy, R * 0.985, 0, TAU); ctx.clip();
        ctx.translate(sx, sy); ctx.rotate(-14 * DEG);
        const per = this.config.periods.sweep;
        const phi = reduced ? 0.55 : (Math.PI / 2) * 0.8 * Math.sin(t * TAU / per);
        const dir = reduced ? 1 : Math.sign(Math.cos(t * TAU / per)) || 1;
        const trail = lod === 0 ? [0] : [0, 0.13, 0.26];
        for (let i = trail.length - 1; i >= 0; i--) {
          const f = phi - dir * trail[i];
          const rx = R * Math.sin(f);
          ctx.strokeStyle = rgba(light ? main : hi, (i === 0 ? 0.95 : 0.35 / i) * p.sweep);
          ctx.lineWidth = Math.max(px1 * (lod ? 1.3 : 1.25), R * (i === 0 ? 0.045 : 0.025));
          ctx.beginPath();
          ctx.ellipse(0, 0, Math.max(0.01, Math.abs(rx)), R, 0, -Math.PI / 2, Math.PI / 2, rx < 0);
          ctx.stroke();
        }
        ctx.restore();
      }

      // flujo interno en S
      const flowA = p.flow * bFlow * (1 + p.lvFlow * lv * 0.4);
      if (flowA > 0.03 && (lod > 0 || p.flow > 0.5)) {
        const amp = R * (p.flowAmp * (1 + p.flowMorph * Math.sin(t * 1.35)) + p.lvFlow * lv * 0.22);
        const ang = rot + this.flowRot + 0.35;
        const L = R * 0.8;
        const ca = Math.cos(ang), sa = Math.sin(ang);
        const N = lod === 2 ? 36 : 22;
        ctx.beginPath();
        for (let i = 0; i <= N; i++) {
          const u = -1 + 2 * i / N;
          const lx = u * L, ly = -amp * Math.sin(Math.PI * u) * (1 - 0.25 * u * u);
          const x = kx + lx * ca - ly * sa, y = ky + lx * sa + ly * ca;
          i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
        }
        const g = ctx.createLinearGradient(kx - L * ca, ky - L * sa, kx + L * ca, ky + L * sa);
        const col = light ? main : hi;
        // destello que viaja por la S (diálogo); la dirección indica quién habla
        const h = ((this.flowPhase % 1) + 1) % 1;
        const stops = [[0, 0], [0.2, 0.35], [0.5, 0.55], [0.8, 0.35], [1, 0]];
        for (const [o, a] of stops) g.addColorStop(o, rgba(col, a * flowA));
        const hp = 0.12 + 0.76 * h;
        g.addColorStop(clamp(hp - 0.09, 0, 1), rgba(col, 0.5 * flowA));
        g.addColorStop(hp, rgba(col, Math.min(1, 1.15 * flowA)));
        g.addColorStop(clamp(hp + 0.09, 0, 1), rgba(col, 0.5 * flowA));
        ctx.strokeStyle = g;
        ctx.lineWidth = Math.max(lod ? 1 : 1.2, R * (lod === 2 ? 0.022 : 0.032));
        ctx.stroke();
        if (!light && lod > 0) {
          ctx.globalCompositeOperation = 'lighter';
          ctx.strokeStyle = rgba(c, 0.07 * flowA);
          ctx.lineWidth = R * 0.08;
          ctx.stroke();
          ctx.globalCompositeOperation = 'source-over';
        }
      }

      // arcos
      if (bArcs > 0) {
        const span = p.span * DEG * (0.25 + 0.75 * bArcs);
        const rA = R * (1 + p.arcOut + p.lvArcs * lv * 0.5 + (1 - bArcs) * 0.25);
        const w = R * p.arcW * (lod === 0 ? 1.3 : 1) * (1 + p.lvArcW * lv * 0.5);
        for (let side = 0; side < 2; side++) {
          const center = rot - Math.PI / 2 + side * Math.PI;
          this._arc(ctx, ax, ay, rA, w, squash, center, span, lod, light, { c, hi, main, deep }, bArcs, side);
        }
      }

      // satélite (executing): un punto en órbita con estela corta
      if (p.sat > 0.02) {
        const per = this.config.periods.sat;
        const a0 = reduced ? -0.6 : t * TAU / per;
        const cr = Math.cos(rot), sr = Math.sin(rot);
        const at = a => {
          const ex = R * 0.74 * Math.cos(a), ey = R * 0.74 * Math.sin(a) * squash;
          return [kx + ex * cr - ey * sr, ky + ex * sr + ey * cr];
        };
        const dotR = Math.max(lod ? 1.6 : 1.4, R * 0.055);
        if (!reduced && lod > 0) {
          const M = 10;
          for (let i = 0; i < M; i++) {
            const pa = at(a0 - 0.9 * (1 - i / M)), pb = at(a0 - 0.9 * (1 - (i + 1) / M));
            ctx.strokeStyle = rgba(light ? main : hi, p.sat * 0.55 * (i / M));
            ctx.lineWidth = dotR * 1.1 * (0.3 + 0.7 * i / M);
            ctx.beginPath(); ctx.moveTo(pa[0], pa[1]); ctx.lineTo(pb[0], pb[1]); ctx.stroke();
          }
        }
        const q = at(a0);
        ctx.fillStyle = rgba(light ? deep : hi, p.sat);
        ctx.beginPath(); ctx.arc(q[0], q[1], dotR, 0, TAU); ctx.fill();
      }

      // núcleo
      if (bDot > 0) {
        const cr = Math.max(lod ? 2 : 1.7, R * p.core * (1 + p.lvCore * lv * 0.9) * (lod === 0 ? 1.25 : 1))
          * (bSphere < 1 ? 1 + (1 - bSphere) * 0.4 * bDot : 1) * bDot;
        // halo de luz (oscuro: aditivo · claro: tenue, no es la señal)
        const gr = cr * (light ? 2.6 : 4.2);
        const g = ctx.createRadialGradient(kx, ky, 0, kx, ky, gr);
        g.addColorStop(0, rgba(c, (light ? 0.28 : 0.55) * p.glow));
        g.addColorStop(1, rgba(c, 0));
        if (!light) ctx.globalCompositeOperation = 'lighter';
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(kx, ky, gr, 0, TAU); ctx.fill();
        ctx.globalCompositeOperation = 'source-over';

        const solid = 1 - p.hollow;
        if (solid > 0.01) {
          const cg = ctx.createRadialGradient(kx - cr * 0.3, ky - cr * 0.3, 0, kx, ky, cr);
          if (light) { cg.addColorStop(0, rgba(main, 1)); cg.addColorStop(1, rgba(deep, 1)); }
          else { cg.addColorStop(0, rgba(WHITE, 1)); cg.addColorStop(0.45, rgba(hi, 1)); cg.addColorStop(1, rgba(c, 1)); }
          ctx.fillStyle = cg;
          ctx.globalAlpha *= solid;
          ctx.beginPath(); ctx.arc(kx, ky, cr, 0, TAU); ctx.fill();
          ctx.globalAlpha /= solid;
        }
        if (p.hollow > 0.01) {
          ctx.strokeStyle = rgba(light ? deep : hi, p.hollow);
          ctx.lineWidth = Math.max(1.1, cr * 0.42);
          ctx.beginPath(); ctx.arc(kx, ky, cr * 1.05, 0, TAU); ctx.stroke();
        }
        // anillo de espera alrededor del núcleo (waiting_approval)
        if (p.halo > 0.02) {
          const per = this.config.periods.halo;
          const ph = reduced ? 0 : Math.sin(t * TAU / per);
          ctx.strokeStyle = rgba(light ? main : hi, p.halo * (0.75 + 0.2 * ph));
          ctx.lineWidth = Math.max(lod ? 1.1 : 1, R * 0.026);
          ctx.beginPath(); ctx.arc(kx, ky, Math.max(cr + 2.2, cr * 2.5 * (1 + 0.05 * ph)), 0, TAU); ctx.stroke();
        }
      }

      ctx.restore();
    }

    /* arco: cinta afinada sobre una elipse inclinada (perspectiva) */
    _arc(ctx, cx, cy, r, w, k, center, span, lod, light, pal, alpha, side) {
      const N = lod === 2 ? 44 : lod === 1 ? 28 : 16;
      const pw = lod === 0 ? 0.38 : 0.62;  // extremos más romos a tamaño chico
      const a0 = center - span / 2;
      // la elipse se orienta con la rotación de los arcos
      const rotE = center + Math.PI / 2 - side * Math.PI;
      const ce = Math.cos(rotE), se = Math.sin(rotE);
      const pt = (rad, th) => {
        const lx = rad * Math.cos(th - rotE), ly = rad * Math.sin(th - rotE) * k;
        return [cx + lx * ce - ly * se, cy + lx * se + ly * ce];
      };
      const outer = [], inner = [];
      for (let i = 0; i <= N; i++) {
        const u = i / N, th = a0 + span * u;
        const prof = Math.pow(Math.sin(Math.PI * u), pw) * (0.8 + 0.4 * u);
        outer.push(pt(r, th));
        inner.push(pt(r - w * prof, th));
      }
      ctx.beginPath();
      ctx.moveTo(outer[0][0], outer[0][1]);
      for (let i = 1; i <= N; i++) ctx.lineTo(outer[i][0], outer[i][1]);
      for (let i = N; i >= 0; i--) ctx.lineTo(inner[i][0], inner[i][1]);
      ctx.closePath();

      const s = outer[0], e = outer[N];
      const g = ctx.createLinearGradient(s[0], s[1], e[0], e[1]);
      const prevA = ctx.globalAlpha;
      ctx.globalAlpha = prevA * alpha;
      if (light) {
        g.addColorStop(0, rgba(pal.main, 1)); g.addColorStop(0.6, rgba(pal.deep, 1)); g.addColorStop(1, rgba(pal.main, 1));
      } else {
        // glow sin shadowBlur: dos trazos aditivos del mismo contorno
        if (lod > 0) {
          ctx.globalCompositeOperation = 'lighter';
          const gw = lod === 2 ? [[0.26, 0.018], [0.15, 0.03], [0.07, 0.05]] : [[0.18, 0.03], [0.07, 0.06]];
          for (const [lw, a] of gw) { ctx.strokeStyle = rgba(pal.c, a); ctx.lineWidth = r * lw; ctx.stroke(); }
          ctx.globalCompositeOperation = 'source-over';
        }
        g.addColorStop(0, rgba(pal.hi, 1)); g.addColorStop(0.55, rgba(pal.c, 1)); g.addColorStop(1, rgba(pal.deep, 1));
      }
      ctx.fillStyle = g;
      ctx.fill();
      if (light) {
        ctx.strokeStyle = rgba(pal.deep, 0.5);
        ctx.lineWidth = Math.max(0.6, r * 0.008);
        ctx.stroke();
      }
      // filo de luz sobre el borde exterior
      if (lod > 0) {
        ctx.beginPath();
        const from = Math.floor(N * 0.15), to = Math.ceil(N * 0.8);
        for (let i = from; i <= to; i++) i === from ? ctx.moveTo(outer[i][0], outer[i][1]) : ctx.lineTo(outer[i][0], outer[i][1]);
        ctx.strokeStyle = light ? rgba(WHITE, 0.55) : rgba(WHITE, 0.45);
        ctx.lineWidth = Math.max(0.8, r * 0.012);
        ctx.stroke();
      }
      ctx.globalAlpha = prevA;
    }
  }

  EliseOrb.STATE_NAMES = Object.keys(STATES);
  if (typeof module !== 'undefined' && module.exports) module.exports = EliseOrb;
  else root.EliseOrb = EliseOrb;
})(typeof globalThis !== 'undefined' ? globalThis : this);
