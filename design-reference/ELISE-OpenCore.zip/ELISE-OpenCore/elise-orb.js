/*!
 * ELISE Orb v3 — "Open Core · Ojo"
 * Canvas 2D puro. Sin WebGL, sin librerías, sin imágenes, sin DOM propio.
 *
 * Una esfera de vidrio, dos medias lunas (las del logo) que funcionan como
 * párpados y un núcleo que es la pupila: mira, se contrae, se dilata, parpadea.
 *
 *   const orb = new EliseOrb();
 *   orb.draw(ctx, cx, cy, size, { state, light, accent, reduced, level, pointer, boot }, now);
 *
 * - ctx ya escalado por devicePixelRatio; size en px CSS; now en ms.
 * - level 0..1 en tiempo real; negativo = voz simulada.
 * - boot: null | { t: ms desde el arranque }. Duración: EliseOrb.bootDuration(reduced).
 * - Lecturas: orb.effectiveState, orb.suggestedFps.
 */
(function (root) {
  'use strict';

  /* ───────────────────────── Tabla de estados ─────────────────────────
   * Párpados
   *   rot      orientación (°): 0 = ojo horizontal (párpados arriba/abajo),
   *            -38 = diagonal de marca (como el logo), 90 = párpados a los costados
   *   span     largo de cada párpado (°)      lid     cierre: grosor en el centro (× R)
   *                                           (0,2 = media luna · 0,5 = entrecerrado · 1 = cerrado)
   *   arcOut   apertura radial (× R)          scale   tamaño de la esfera
   *   wobble/wobbleP  deriva lenta (°, s)     breath/breathP  respiración
   * Pupila (el núcleo)
   *   core     radio (× R)   glow halo        gazeX/gazeY  hacia dónde mira (× R)
   *   drift/driftP  pequeño recorrido circular de la mirada (pensar)
   *   saccade  0..1 mirada que salta de un punto a otro (buscar)
   *   hollow   pupila hueca (error)           halo    anillo quieto alrededor (espera)
   *   iris     segmentos que giran alrededor de la pupila (ejecutar)
   * Voz
   *   lightUp  habla ELISE: la luz nace en la pupila y llena el vidrio
   *   rimLight habla la persona: la luz entra desde el borde del vidrio hacia la pupila
   *   lvCore / lvLids  cuánto mueve el nivel de voz la pupila y los párpados
   * Gestos y señales
   *   blink    parpadeo al entrar · blinkEvery  parpadeo periódico (s, 0 = nunca). Apagados por defecto.
   *   nod / shake  "sí" / "no" · ping  pulso hacia afuera
   * Color
   *   bright   intensidad · tint [color, cantidad] (confirma, nunca es la única señal)
   *   dur      ms; vuelve solo a idle
   */
  const STATES = {
    idle: {
      scale: 1, rot: -38, span: 142, lid: 0.2, arcOut: 0,
      wobble: 3, wobbleP: 12, breath: 0.012, breathP: 5.5,
      core: 0.12, glow: 0.8, gazeX: 0, gazeY: 0, drift: 0, driftP: 3, saccade: 0,
      hollow: 0, halo: 0, iris: 0, lightUp: 0,
      rimLight: 0, lvCore: 0, lvLids: 0,
      blink: 0, blinkEvery: 0, nod: 0, shake: 0, ping: 0,
      bright: 0.9, tint: [null, 0]
    },
    listening: {
      scale: 1.03, rot: 0, span: 150, lid: 0.14, arcOut: 0.12, wobble: 1.5, wobbleP: 6,
      breath: 0.02, breathP: 2.8, core: 0.135, glow: 0.95, blinkEvery: 0, bright: 1
    },
    user_speaking: {
      scale: 1.02, rot: 0, span: 146, lid: 0.16, arcOut: 0.05, wobble: 0, breath: 0,
      core: 0.12, glow: 1, rimLight: 1, lvCore: 0.35, lvLids: 0.3, blinkEvery: 0, bright: 1
    },
    thinking: {
      rot: -20, span: 160, lid: 0.34, wobble: 0, breath: 0.006, breathP: 2,
      core: 0.1, glow: 0.75, gazeX: 0.2, gazeY: -0.24, drift: 0.07, driftP: 3.2, blinkEvery: 0, bright: 0.95
    },
    searching: {
      rot: 0, span: 150, lid: 0.14, arcOut: 0.06, wobble: 0,
      core: 0.1, glow: 0.85, saccade: 1, blinkEvery: 0, bright: 1
    },
    speaking: {
      rot: -38, span: 142, lid: 0.2, wobble: 2, wobbleP: 4,
      core: 0.14, glow: 1, lightUp: 1, lvCore: 0.9, lvLids: 0.25, bright: 1
    },
    executing: {
      rot: 0, span: 168, lid: 0.4, wobble: 0, core: 0.11, glow: 0.9, iris: 1, blinkEvery: 0, bright: 1
    },
    waiting_approval: {
      rot: 90, span: 158, lid: 0.16, arcOut: 0.02, wobble: 0, breath: 0.004, breathP: 3,
      core: 0.11, glow: 0.85, halo: 1, blinkEvery: 0, bright: 0.95, tint: ['#A9C7FF', 0.22]
    },
    success: {
      rot: -38, span: 150, lid: 0.18, arcOut: 0.08, wobble: 0, core: 0.17, glow: 1.3, nod: 1,
      blinkEvery: 0, bright: 1, tint: ['#4BE3B0', 0.38], dur: 900
    },
    attention: {
      rot: 0, span: 146, lid: 0.14, arcOut: 0.1, wobble: 0, core: 0.095, glow: 1, ping: 1,
      blinkEvery: 0, bright: 1, tint: ['#F6B44E', 0.4]
    },
    error: {
      rot: -38, span: 150, lid: 0.42, arcOut: -0.02, wobble: 0, breath: 0,
      core: 0.13, glow: 0.5, hollow: 1, shake: 1, blinkEvery: 0, bright: 0.95,
      tint: ['#FF6A5C', 0.5], dur: 1200
    },
    sleeping: {
      scale: 0.92, rot: 0, span: 176, lid: 0.86, wobble: 0, breath: 0.03, breathP: 8,
      core: 0.07, glow: 0.3, blinkEvery: 0, bright: 0.42, tint: ['#8A9BA3', 0.55]
    }
  };
  for (const k in STATES) if (k !== 'idle') STATES[k] = Object.assign({}, STATES.idle, STATES[k]);

  const CONFIG = {
    accent: '#22D3EE',
    tauMotion: 150, tauColor: 200, tauPointer: 133,
    afterErrorDim: { bright: 0.6, tint: ['#8A9BA3', 0.3] },
    reduced: { motion: 0, level: 0.5, saccadeDwell: 2.2 },
    boot: { dot: 600, sphere: 800, arcs: 900, total: 2600, reduced: 350 },
    pointerLean: 0.03,   // desplazamiento de todo el ojo hacia el puntero (× R)
    pointerGaze: 0.14,   // cuánto mira la pupila hacia el puntero (× R) — discreto a propósito
    blinkMs: 300,        // parpadeo: cierra ~110 ms, abre ~190 ms
    saccade: { dwell: 0.62, move: 0.13, rx: 0.4, ry: 0.26 },
    periods: { ping: 1.6, halo: 2.4, iris: 1.3 }
  };

  const NUM_KEYS = Object.keys(STATES.idle).filter(k => typeof STATES.idle[k] === 'number');
  const TAU = Math.PI * 2, DEG = Math.PI / 180;

  const _hexCache = {};
  function hex(c) {
    if (_hexCache[c]) return _hexCache[c];
    let s = String(c).trim().replace('#', '');
    if (s.length === 3) s = s.split('').map(x => x + x).join('');
    const n = parseInt(s.slice(0, 6), 16);
    return (_hexCache[c] = isNaN(n) ? [34, 211, 238] : [(n >> 16) & 255, (n >> 8) & 255, n & 255]);
  }
  const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
  const rgba = (c, a) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a < 0 ? 0 : a > 1 ? 1 : +a.toFixed(3)})`;
  const WHITE = [255, 255, 255], INK = [5, 50, 61], INK_DEEP = [2, 28, 34], NIGHT = [0, 59, 74];
  const clamp = (x, a, b) => (x < a ? a : x > b ? b : x);
  const ease = t => (t <= 0 ? 0 : t >= 1 ? 1 : t * t * (3 - 2 * t));
  const easeOut = t => 1 - Math.pow(1 - clamp(t, 0, 1), 3);
  // pseudoaleatorio determinista para las sacadas
  const hash = n => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
  // curva de parpadeo 0→1→0 (cierre rápido, apertura más lenta)
  const blinkCurve = q => (q <= 0 || q >= 1 ? 0 : q < 0.37 ? ease(q / 0.37) : 1 - ease((q - 0.37) / 0.63));

  class EliseOrb {
    constructor(options) {
      options = options || {};
      this.states = options.states || STATES;
      this.config = Object.assign({}, CONFIG, options.config);
      this.p = Object.assign({}, this.states.idle);
      this.color = hex(this.config.accent).slice();
      this.ptr = { x: 0, y: 0 };
      this.level = 0; this.t = 0; this.last = null;
      this.inState = null; this.stateStart = 0; this.stateElapsed = 0;
      this.dimAfterError = false;
      this.effectiveState = 'idle';
      this.suggestedFps = 60;
      this.blinkAt = -1;            // s del reloj interno en que empezó el último parpadeo
      this.nextBlink = 6;           // primer parpadeo de idle
      this.sac = { x: 0, y: 0 };    // posición suavizada de la sacada
      this._first = true;
    }
    static bootDuration(reduced) { return reduced ? CONFIG.boot.reduced : CONFIG.boot.total; }
    static get STATES() { return STATES; }
    static get CONFIG() { return CONFIG; }

    _update(input, now) {
      const dtMs = this.last == null ? 16 : clamp(now - this.last, 0, 100);
      this.last = now;
      const dt = dtMs / 1000;
      this.t += dt;
      const reduced = !!input.reduced;

      const req = this.states[input.state] ? input.state : 'idle';
      if (req !== this.inState) {
        this.dimAfterError = false; this.inState = req; this.stateStart = now;
        if (this.states[req].blink && !reduced) this.blinkAt = this.t + 0.06;
      }
      let eff = req;
      const def = this.states[req];
      const since = now - this.stateStart;
      if (def.dur && since > def.dur) { eff = 'idle'; if (req === 'error') this.dimAfterError = true; }
      this.effectiveState = eff;
      this.stateElapsed = since;

      const target = Object.assign({}, this.states[eff]);
      if (eff === 'idle' && this.dimAfterError) {
        target.bright = this.config.afterErrorDim.bright;
        target.tint = this.config.afterErrorDim.tint;
      }
      if (reduced) {
        const m = this.config.reduced.motion;
        target.wobble *= m; target.breath *= m; target.drift *= m;
        target.shake = 0; target.nod = 0;
      }
      const kM = this._first ? 1 : 1 - Math.exp(-dtMs / this.config.tauMotion);
      const kC = this._first ? 1 : 1 - Math.exp(-dtMs / this.config.tauColor);
      const kP = this._first ? 1 : 1 - Math.exp(-dtMs / this.config.tauPointer);
      this._first = false;
      for (const k of NUM_KEYS) this.p[k] += (target[k] - this.p[k]) * kM;
      this.p.shake = target.shake; this.p.nod = target.nod;

      // parpadeo periódico (solo en reposo y sin reduced motion)
      if (target.blinkEvery > 0 && !reduced) {
        if (this.t >= this.nextBlink) {
          this.blinkAt = this.t;
          this.nextBlink = this.t + target.blinkEvery * (0.75 + 0.5 * hash(Math.floor(this.t)));
        }
      } else if (this.nextBlink < this.t + 4) this.nextBlink = this.t + 4;

      const acc = hex(input.accent || this.config.accent);
      const tc = target.tint && target.tint[0] ? mix(acc, hex(target.tint[0]), target.tint[1]) : acc;
      this.color = mix(this.color, tc, kC);

      const px = input.pointer ? clamp(+input.pointer.x || 0, -1, 1) : 0;
      const py = input.pointer ? clamp(+input.pointer.y || 0, -1, 1) : 0;
      const pm = reduced ? 0.3 : 1;
      this.ptr.x += (px * pm - this.ptr.x) * kP;
      this.ptr.y += (py * pm - this.ptr.y) * kP;

      let lv = typeof input.level === 'number' ? input.level : 0;
      if (lv < 0) lv = this._simLevel(this.t);
      lv = clamp(lv, 0, 1);
      this.level += (lv - this.level) * (1 - Math.exp(-dtMs / (lv > this.level ? 45 : 160)));

      // sacadas: saltos rápidos entre puntos, pausas entre medio
      const S = this.config.saccade;
      const dwell = reduced ? this.config.reduced.saccadeDwell : S.dwell;
      const k = Math.floor(this.t / dwell);
      const tgt = i => {
        if (i < 0) return [0, 0];
        const a = hash(i * 1.7 + 3) * TAU, r = 0.45 + 0.55 * hash(i * 2.3 + 9);
        return [Math.cos(a) * r * S.rx, Math.sin(a) * r * S.ry];
      };
      const from = tgt(k - 1), to = tgt(k);
      const m = easeOut((this.t - k * dwell) / (reduced ? 0.6 : S.move));
      this.sac.x = from[0] + (to[0] - from[0]) * m;
      this.sac.y = from[1] + (to[1] - from[1]) * m;

      const calm = eff === 'idle' || eff === 'waiting_approval';
      this.suggestedFps = eff === 'sleeping' || (reduced && calm) ? 20 : calm || reduced ? 30 : 60;
      return reduced;
    }

    _simLevel(t) {
      const syl = Math.abs(Math.sin(t * 7.1)) * (0.55 + 0.45 * Math.sin(t * 2.3 + 1.1));
      const word = 0.5 + 0.5 * Math.sin(t * 1.27);
      const phrase = Math.sin(t * 0.55) > -0.55 ? 1 : 0.08;
      return clamp((0.15 + syl * 0.85) * (0.45 + 0.55 * word) * phrase, 0, 1);
    }

    draw(ctx, cx, cy, size, input, now) {
      input = input || {};
      if (now == null) now = typeof performance !== 'undefined' ? performance.now() : Date.now();
      const reduced = this._update(input, now);
      const p = this.p, t = this.t, lv = this.level * (reduced ? this.config.reduced.level : 1);
      const light = !!input.light;
      const lod = size < 64 ? 0 : size < 220 ? 1 : 2;

      let bDot = 1, bSphere = 1, bArcs = 1, bAlpha = 1;
      if (input.boot && typeof input.boot.t === 'number') {
        const b = this.config.boot, bt = input.boot.t;
        if (reduced) bAlpha = ease(bt / b.reduced);
        else {
          bDot = easeOut(bt / b.dot);
          bSphere = ease((bt - b.dot) / b.sphere);
          bArcs = easeOut((bt - b.dot - b.sphere * 0.75) / b.arcs);
        }
      }

      const c = this.color;
      let hi, main, deep;
      if (light) { hi = mix(c, INK, 0.12); main = mix(c, INK, 0.42); deep = mix(c, INK_DEEP, 0.66); }
      else { hi = mix(c, WHITE, 0.62); main = c; deep = mix(c, NIGHT, 0.4); }

      const breath = 1 + p.breath * Math.sin(t * TAU / Math.max(0.5, p.breathP));
      const R = size * 0.36 * p.scale * breath;
      let ox = 0, oy = 0;
      const se = this.stateElapsed / 1000;
      if (p.shake && !reduced && se < 0.9) ox += R * 0.1 * Math.sin(se * TAU * 6.5) * Math.exp(-se * 3.4);
      if (p.nod && !reduced && se < 0.8) oy -= R * 0.07 * Math.sin(se * TAU * 2.4) * Math.exp(-se * 4);
      const lean = this.config.pointerLean;
      const X = cx + ox, Y = cy + oy;
      // esfera y párpados se mueven juntos (los párpados nunca se salen del borde);
      // la inclinación hacia el puntero la dan la mirada de la pupila y un leve giro de los párpados
      const sx = X + this.ptr.x * R * lean, sy = Y + this.ptr.y * R * lean;
      const ax = sx, ay = sy;

      // mirada de la pupila
      const dA = t * TAU / Math.max(0.5, p.driftP);
      let gx = p.gazeX + p.drift * Math.cos(dA) + p.saccade * this.sac.x + this.ptr.x * this.config.pointerGaze;
      let gy = p.gazeY + p.drift * Math.sin(dA) * 0.7 + p.saccade * this.sac.y + this.ptr.y * this.config.pointerGaze;
      const gl = Math.hypot(gx, gy);
      if (gl > 0.5) { gx *= 0.5 / gl; gy *= 0.5 / gl; }
      const kx = sx + gx * R, ky = sy + gy * R;

      // parpadeo
      let blink = 0;
      if (this.blinkAt >= 0 && !reduced) blink = blinkCurve((t - this.blinkAt) / (this.config.blinkMs / 1000));

      const wob = p.wobble * DEG * Math.sin(t * TAU / Math.max(0.5, p.wobbleP));
      const rot = p.rot * DEG + wob + (1 - bArcs) * -1.6 + this.ptr.x * 0.1 - this.ptr.y * 0.05;

      ctx.save();
      ctx.globalAlpha = clamp(p.bright, 0, 1) * bAlpha;
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      const px1 = Math.max(1, size / 260);
      const col = light ? main : hi;

      // halo ambiente (solo oscuro)
      if (!light && lod > 0 && bSphere > 0) {
        const g = ctx.createRadialGradient(sx, sy, R * 0.2, sx, sy, R * 1.65);
        g.addColorStop(0, rgba(c, 0.1 * p.glow * bSphere)); g.addColorStop(1, rgba(c, 0));
        ctx.fillStyle = g; ctx.fillRect(sx - R * 1.65, sy - R * 1.65, R * 3.3, R * 3.3);
      }

      // pulso hacia afuera (attention)
      if (p.ping > 0.02) {
        const per = this.config.periods.ping;
        const base = R * (1.1 + Math.max(0, p.arcOut));
        const ph = reduced ? 0.45 : (t % per) / per;
        if (!reduced && lod === 0) { // a tamaño chico, un anillo fijo mantiene la señal entre pulsos
          ctx.strokeStyle = rgba(col, 0.3 * p.ping);
          ctx.lineWidth = Math.max(px1, R * 0.018);
          ctx.beginPath(); ctx.arc(sx, sy, base, 0, TAU); ctx.stroke();
        }
        ctx.strokeStyle = rgba(col, (reduced ? 0.55 : Math.pow(1 - ph, 1.4) * 0.75) * p.ping);
        ctx.lineWidth = Math.max(px1 * 1.1, R * 0.035 * (reduced ? 0.8 : 1 - ph * 0.6));
        ctx.beginPath(); ctx.arc(sx, sy, base + R * 0.28 * easeOut(ph), 0, TAU); ctx.stroke();
      }

      // esfera de vidrio
      if (bSphere > 0) {
        if (lod > 0) {
          const g = ctx.createRadialGradient(sx - R * 0.3, sy - R * 0.35, R * 0.1, sx, sy, R);
          if (light) { g.addColorStop(0, 'rgba(255,255,255,0.35)'); g.addColorStop(1, rgba(main, 0.08 * bSphere)); }
          else { g.addColorStop(0, rgba(c, 0.015 * bSphere)); g.addColorStop(0.75, rgba(c, 0.05 * bSphere)); g.addColorStop(1, rgba(c, 0.13 * bSphere)); }
          ctx.fillStyle = g;
          ctx.beginPath(); ctx.arc(sx, sy, R, 0, TAU); ctx.fill();
        }
        ctx.strokeStyle = light ? rgba(deep, (lod ? 0.26 : 0.32) * bSphere) : rgba(hi, (lod ? 0.2 : 0.26) * bSphere);
        ctx.lineWidth = Math.max(lod ? 0.75 : 0.9, R * 0.011);
        ctx.beginPath(); ctx.arc(sx, sy, R, -Math.PI / 2, -Math.PI / 2 + TAU * bSphere); ctx.stroke();
      }

      // ── dentro del ojo (los párpados lo tapan después) ──
      ctx.save();
      ctx.beginPath(); ctx.arc(sx, sy, R * 0.99, 0, TAU); ctx.clip();

      // habla la persona: la luz entra desde el borde del vidrio hacia la pupila
      if (p.rimLight > 0.02 && bSphere > 0.5) {
        const a = p.rimLight * (light ? 0.05 + 0.22 * lv : 0.07 + 0.4 * lv);
        const g = ctx.createRadialGradient(sx, sy, R * (0.62 - 0.3 * lv), sx, sy, R);
        g.addColorStop(0, rgba(light ? main : c, 0));
        g.addColorStop(1, rgba(light ? main : c, a));
        if (!light) ctx.globalCompositeOperation = 'lighter';
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(sx, sy, R, 0, TAU); ctx.fill();
        ctx.globalCompositeOperation = 'source-over';
      }

      // hablar: el interior se ilumina desde la pupila, al ritmo de la voz
      if (p.lightUp > 0.02 && bDot > 0.5) {
        const a = p.lightUp * (light ? 0.05 + 0.2 * lv : 0.06 + 0.38 * lv);
        const g = ctx.createRadialGradient(kx, ky, 0, kx, ky, R * (0.75 + 0.3 * lv));
        g.addColorStop(0, rgba(light ? main : c, a));
        g.addColorStop(0.5, rgba(light ? main : c, a * 0.4));
        g.addColorStop(1, rgba(light ? main : c, 0));
        if (!light) ctx.globalCompositeOperation = 'lighter';
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(sx, sy, R, 0, TAU); ctx.fill();
        ctx.globalCompositeOperation = 'source-over';
      }

      // pupila
      if (bDot > 0) {
        const cr = Math.max(lod ? 2 : 1.7, R * p.core * (1 + p.lvCore * lv * 0.9) * (lod === 0 ? 1.25 : 1))
          * (bSphere < 1 ? 1 + (1 - bSphere) * 0.4 * bDot : 1) * bDot;
        const gr = cr * (light ? 2.6 : 4.2);
        const g = ctx.createRadialGradient(kx, ky, 0, kx, ky, gr);
        g.addColorStop(0, rgba(c, (light ? 0.28 : 0.55) * p.glow)); g.addColorStop(1, rgba(c, 0));
        if (!light) ctx.globalCompositeOperation = 'lighter';
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(kx, ky, gr, 0, TAU); ctx.fill();
        ctx.globalCompositeOperation = 'source-over';
        const solid = 1 - p.hollow;
        if (solid > 0.01) {
          const cg = ctx.createRadialGradient(kx - cr * 0.3, ky - cr * 0.3, 0, kx, ky, cr);
          if (light) { cg.addColorStop(0, rgba(main, 1)); cg.addColorStop(1, rgba(deep, 1)); }
          else { cg.addColorStop(0, rgba(WHITE, 1)); cg.addColorStop(0.45, rgba(hi, 1)); cg.addColorStop(1, rgba(c, 1)); }
          ctx.fillStyle = cg;
          const ga = ctx.globalAlpha; ctx.globalAlpha = ga * solid;
          ctx.beginPath(); ctx.arc(kx, ky, cr, 0, TAU); ctx.fill();
          ctx.globalAlpha = ga;
        }
        if (p.hollow > 0.01) {
          ctx.strokeStyle = rgba(light ? deep : hi, p.hollow);
          ctx.lineWidth = Math.max(1.1, cr * 0.42);
          ctx.beginPath(); ctx.arc(kx, ky, cr * 1.05, 0, TAU); ctx.stroke();
        }
        // espera: anillo quieto (iris en reposo)
        if (p.halo > 0.02) {
          const ph = reduced ? 0 : Math.sin(t * TAU / this.config.periods.halo);
          ctx.strokeStyle = rgba(col, p.halo * (0.75 + 0.2 * ph));
          ctx.lineWidth = Math.max(lod ? 1.1 : 1, R * 0.026);
          ctx.beginPath(); ctx.arc(kx, ky, Math.max(cr + 2.2, cr * 2.5 * (1 + 0.05 * ph)), 0, TAU); ctx.stroke();
        }
        // ejecutar: iris que gira (dos segmentos, como un diafragma trabajando)
        if (p.iris > 0.02) {
          const a0 = reduced ? 0.6 : t * TAU / this.config.periods.iris;
          const ir = Math.max(cr + 2.6, cr * 2.4);
          ctx.strokeStyle = rgba(col, p.iris * 0.95);
          ctx.lineWidth = Math.max(lod ? 1.4 : 1.3, R * 0.04);
          ctx.lineCap = 'round';
          for (let i = 0; i < 2; i++) {
            ctx.beginPath(); ctx.arc(kx, ky, ir, a0 + i * Math.PI, a0 + i * Math.PI + 1.15); ctx.stroke();
          }
          if (lod > 0) {
            ctx.strokeStyle = rgba(col, p.iris * 0.18);
            ctx.lineWidth = Math.max(1, R * 0.012);
            ctx.beginPath(); ctx.arc(kx, ky, ir, 0, TAU); ctx.stroke();
          }
        }
      }
      ctx.restore();

      // reflejo del vidrio (por encima de la pupila, como en un ojo real)
      if (bSphere > 0.5 && lod > 0) {
        ctx.strokeStyle = light ? rgba(WHITE, 0.9 * bSphere) : rgba(WHITE, 0.12 * bSphere);
        ctx.lineWidth = Math.max(1, R * (light ? 0.02 : 0.012));
        ctx.beginPath(); ctx.arc(sx, sy, R * 0.9, -2.55, -1.75); ctx.stroke();
      }

      // ── párpados ──
      if (bArcs > 0) {
        const close = clamp(p.lid + (1 - p.lid) * blink, 0, 1);
        const span = (p.span + (178 - p.span) * blink) * DEG * (0.3 + 0.7 * bArcs);
        const Ro = R * (1 + p.arcOut * (1 - blink) + p.lvLids * lv * 0.5 + (1 - bArcs) * 0.25);
        const T = R * close * (lod === 0 ? (close < 0.5 ? 1.3 : 1) : 1);
        const prev = ctx.globalAlpha;
        ctx.globalAlpha = prev * bArcs;
        for (let k = 0; k < 2; k++) this._lid(ctx, ax, ay, Ro, T, rot - Math.PI / 2 + k * Math.PI, span / 2, lod, light, { c, hi, main, deep }, R);
        ctx.globalAlpha = prev;
      }
      ctx.restore();
    }

    /* Párpado = media luna del logo. Borde exterior: arco de círculo.
     * Borde interior: curva por los dos extremos y por un punto a "T" del borde.
     * Con T chico es la media luna; con T ≈ R los dos párpados se encuentran (ojo cerrado). */
    _lid(ctx, cx, cy, Ro, T, dir, a, lod, light, pal, R) {
      const ux = Math.cos(dir), uy = Math.sin(dir), tx = -uy, ty = ux;
      const p1 = [cx + Ro * Math.cos(dir - a), cy + Ro * Math.sin(dir - a)];
      const p2 = [cx + Ro * Math.cos(dir + a), cy + Ro * Math.sin(dir + a)];
      // más grueso hacia un extremo, como el logo; se vuelve simétrico al cerrarse (parpadeo limpio)
      const skew = lod === 0 ? 0 : 0.22 * Math.min(T, R * 0.4) * (1 - clamp((T / R - 0.45) / 0.4, 0, 1));
      const m = Ro - T;
      const M = [cx + ux * m + tx * skew, cy + uy * m + ty * skew];
      const Q = [2 * M[0] - (p1[0] + p2[0]) / 2, 2 * M[1] - (p1[1] + p2[1]) / 2];
      const path = () => {
        ctx.beginPath();
        ctx.arc(cx, cy, Ro, dir - a, dir + a, false);
        ctx.quadraticCurveTo(Q[0], Q[1], p1[0], p1[1]);
        ctx.closePath();
      };
      const g = ctx.createLinearGradient(p1[0], p1[1], p2[0], p2[1]);
      if (light) { g.addColorStop(0, rgba(pal.main, 1)); g.addColorStop(1, rgba(pal.deep, 1)); }
      else {
        if (lod > 0) {
          path(); ctx.globalCompositeOperation = 'lighter';
          const gw = lod === 2 ? [[0.22, 0.02], [0.12, 0.035], [0.05, 0.05]] : [[0.14, 0.03], [0.05, 0.06]];
          for (const [lw, al] of gw) { ctx.strokeStyle = rgba(pal.c, al); ctx.lineWidth = R * lw; ctx.stroke(); }
          ctx.globalCompositeOperation = 'source-over';
        }
        g.addColorStop(0, rgba(pal.hi, 1)); g.addColorStop(0.5, rgba(pal.c, 1)); g.addColorStop(1, rgba(pal.deep, 1));
      }
      path(); ctx.fillStyle = g; ctx.fill();
      if (light) { ctx.strokeStyle = rgba(pal.deep, 0.35); ctx.lineWidth = Math.max(0.6, R * 0.007); ctx.stroke(); }
      if (lod > 0) {
        // filo de luz sobre el borde exterior
        ctx.beginPath();
        ctx.arc(cx, cy, Ro - Math.max(0.6, R * 0.012), dir - a * 0.75, dir + a * 0.45, false);
        ctx.strokeStyle = rgba(WHITE, light ? 0.55 : 0.5);
        ctx.lineWidth = Math.max(0.8, R * 0.014);
        ctx.stroke();
      }
    }
  }

  EliseOrb.STATE_NAMES = Object.keys(STATES);
  if (typeof module !== 'undefined' && module.exports) module.exports = EliseOrb;
  else root.EliseOrb = EliseOrb;
})(typeof globalThis !== 'undefined' ? globalThis : this);
