export type EliseOrbState =
  | 'idle' | 'listening' | 'user_speaking' | 'thinking' | 'searching' | 'speaking'
  | 'executing' | 'waiting_approval' | 'success' | 'attention' | 'error' | 'sleeping';

export interface EliseOrbInput {
  state: EliseOrbState;
  /** true = modo claro (fondo casi blanco). El contraste no depende del brillo. */
  light: boolean;
  /** Color de energía. Cyan (#22D3EE) por defecto. */
  accent?: string;
  /** prefers-reduced-motion: casi quieto, estados aún distinguibles; boot = fundido de 350 ms. */
  reduced: boolean;
  /** Nivel de voz 0..1 en tiempo real. Negativo = el Orb simula una voz. */
  level: number;
  /** Posición del puntero respecto del Orb, -1..1 en cada eje. */
  pointer: { x: number; y: number };
  /** Arranque en curso: ms transcurridos. null cuando terminó. */
  boot?: { t: number } | null;
}

export interface EliseOrbStateParams {
  scale: number; rot: number; span: number; arcW: number; arcOut: number; squash: number;
  spin: number; wobble: number; wobbleP: number; breath: number; breathP: number;
  flow: number; flowAmp: number; flowSpeed: number; flowTurn: number; flowMorph: number;
  core: number; glow: number; hollow: number; halo: number;
  sweep: number; sat: number; ping: number; shake: number; nod: number;
  lvArcs: number; lvCore: number; lvFlow: number; lvArcW: number;
  bright: number; tint: [string | null, number]; dur?: number;
}

export default class EliseOrb {
  constructor(options?: {
    states?: Record<EliseOrbState, EliseOrbStateParams>;
    config?: Partial<typeof EliseOrb.CONFIG>;
  });
  /** Dibuja un cuadro. ctx ya escalado por devicePixelRatio; size en px CSS; now en ms. */
  draw(ctx: CanvasRenderingContext2D, cx: number, cy: number, size: number, input: EliseOrbInput, now?: number): void;
  /** Estado que se muestra (success y error vuelven solos a idle). */
  readonly effectiveState: EliseOrbState;
  /** 60 en estados activos, 30 en reposo, 20 dormida o reduced en reposo. */
  readonly suggestedFps: number;
  static bootDuration(reduced: boolean): number;
  static readonly STATES: Record<EliseOrbState, EliseOrbStateParams>;
  static readonly CONFIG: {
    accent: string; tauMotion: number; tauColor: number; tauPointer: number;
    afterErrorDim: { bright: number; tint: [string, number] };
    reduced: { motion: number; flowSpeed: number; level: number };
    boot: { dot: number; sphere: number; arcs: number; total: number; reduced: number };
    pointerLean: number;
    periods: { ping: number; sweep: number; sat: number; halo: number };
  };
  static readonly STATE_NAMES: EliseOrbState[];
}
