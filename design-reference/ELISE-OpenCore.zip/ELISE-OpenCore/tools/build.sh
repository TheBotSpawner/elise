#!/bin/sh
# Arma dist/ con la página (nota embebida), el Orb, el logo y los íconos
set -e
cd "$(dirname "$0")/.."
rm -rf dist && mkdir -p dist
python3 -c "
s=open('index.html').read(); n=open('NOTA.md').read()
open('dist/index.html','w').write(s.replace('%%NOTA%%', n.replace('</script','<\\\\/script')))"
cp elise-orb.js elise-orb.d.ts NOTA.md dist/
cp -r logo icons dist/
