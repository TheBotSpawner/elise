"""Genera el sistema de logo de ELISE (SVG). Uso: python3 logo.py <dir_salida>"""
import math, os, sys

OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)

CYAN = '#22D3EE'
INK = '#0B1A20'        # monocroma oscura
TEAL_DEEP = '#0A6573'  # color sobre fondo claro
TEAL = '#0E8597'


def circ_intersect(c0, r0, c1, r1):
    dx, dy = c1[0] - c0[0], c1[1] - c0[1]
    d = math.hypot(dx, dy)
    a = (r0 * r0 - r1 * r1 + d * d) / (2 * d)
    h = math.sqrt(max(0, r0 * r0 - a * a))
    mx, my = c0[0] + a * dx / d, c0[1] + a * dy / d
    return (mx + h * dy / d, my - h * dx / d), (mx - h * dy / d, my + h * dx / d)


def crescent(cx, cy, Ro, dir_deg, T, span_deg, skew_deg):
    """Media luna: arco exterior del círculo (cx,cy,Ro) y arco interior de otro círculo
    desplazado. Puntas afiladas; skew la hace más gruesa hacia un extremo."""
    a = math.radians(span_deg / 2)
    d = ((Ro - T) ** 2 - Ro ** 2) / (2 * (Ro - T - Ro * math.cos(a)))  # negativo
    Ri = Ro - T - d
    u = math.radians(dir_deg + skew_deg)
    ic = (cx + d * math.cos(u), cy + d * math.sin(u))
    p1, p2 = circ_intersect((cx, cy), Ro, ic, Ri)
    # ordenar: p1 antes que p2 en sentido horario (pantalla) alrededor de dir
    def ang(p):
        return math.atan2(p[1] - cy, p[0] - cx)
    dd = math.radians(dir_deg)
    def rel(p):
        x = ang(p) - dd
        return math.atan2(math.sin(x), math.cos(x))
    if rel(p1) > rel(p2):
        p1, p2 = p2, p1
    f = lambda v: f'{v:.2f}'.rstrip('0').rstrip('.')
    return (f'M{f(p1[0])} {f(p1[1])}A{f(Ro)} {f(Ro)} 0 0 1 {f(p2[0])} {f(p2[1])}'
            f'A{f(Ri)} {f(Ri)} 0 0 0 {f(p1[0])} {f(p1[1])}Z')


# Geometrías del símbolo en una caja de 120 × 120
GEOM = {
    # estándar: afilado, elegante
    'full':  dict(Ro=50, T=12.5, span=142, skew=9, rot=-38, core=8.5),
    # chico (32–64 px): más grueso, puntas más cortas, núcleo más grande
    'small': dict(Ro=51, T=17, span=132, skew=6, rot=-38, core=11.5),
    # micro (16 px): máxima masa, aperturas grandes
    'micro': dict(Ro=52, T=21, span=120, skew=0, rot=-38, core=14),
}


def symbol_shapes(g, cx=60, cy=60):
    top = crescent(cx, cy, g['Ro'], g['rot'] - 90, g['T'], g['span'], g['skew'])
    bot = crescent(cx, cy, g['Ro'], g['rot'] + 90, g['T'], g['span'], g['skew'])
    return top, bot, (cx, cy, g['core'])


def symbol_group(variant, geom='full', tx=0, ty=0, s=1, uid='a'):
    g = GEOM[geom]
    top, bot, (cx, cy, cr) = symbol_shapes(g)
    defs, body = '', ''
    if variant == 'color':          # sobre fondo oscuro
        defs = (f'<linearGradient id="{uid}g" x1="14" y1="20" x2="106" y2="100" gradientUnits="userSpaceOnUse">'
                f'<stop offset="0" stop-color="#B4F7FC"/><stop offset=".5" stop-color="{CYAN}"/>'
                f'<stop offset="1" stop-color="#0FA7C0"/></linearGradient>'
                f'<radialGradient id="{uid}c" cx="{cx}" cy="{cy}" r="{cr*3}" gradientUnits="userSpaceOnUse">'
                f'<stop offset="0" stop-color="{CYAN}" stop-opacity=".45"/><stop offset="1" stop-color="{CYAN}" stop-opacity="0"/></radialGradient>')
        body = (f'<circle cx="{cx}" cy="{cy}" r="{cr*3}" fill="url(#{uid}c)"/>'
                f'<path d="{top}" fill="url(#{uid}g)"/><path d="{bot}" fill="url(#{uid}g)"/>'
                f'<circle cx="{cx}" cy="{cy}" r="{cr}" fill="#9EF6FD"/>')
    elif variant == 'color-onlight':
        defs = (f'<linearGradient id="{uid}g" x1="14" y1="20" x2="106" y2="100" gradientUnits="userSpaceOnUse">'
                f'<stop offset="0" stop-color="{TEAL}"/><stop offset="1" stop-color="{TEAL_DEEP}"/></linearGradient>')
        body = (f'<path d="{top}" fill="url(#{uid}g)"/><path d="{bot}" fill="url(#{uid}g)"/>'
                f'<circle cx="{cx}" cy="{cy}" r="{cr}" fill="{CYAN}"/>'
                f'<circle cx="{cx}" cy="{cy}" r="{cr - 1.2}" fill="none" stroke="{TEAL_DEEP}" stroke-width="2.4"/>')
    else:
        col = '#FFFFFF' if variant == 'mono-light' else INK
        body = f'<path d="{top}" fill="{col}"/><path d="{bot}" fill="{col}"/><circle cx="{cx}" cy="{cy}" r="{cr}" fill="{col}"/>'
    tr = f' transform="translate({tx} {ty}) scale({s})"' if (tx or ty or s != 1) else ''
    return defs, f'<g{tr}>{body}</g>'


# ── Wordmark: ELISE geométrico, trazos finos, muy espaciado (alto de mayúscula = 100) ──
SW = 8
LETTERS = {
    'E': (74, 'M74 4H4V96H74M4 50H66'),
    'L': (66, 'M4 0V96H66'),
    'I': (8,  'M4 0V100'),
    'S': (80, 'M76 4H20A16 16 0 0 0 4 20V34A16 16 0 0 0 20 50H60A16 16 0 0 1 76 66V80A16 16 0 0 1 60 96H0'),
}
TRACK = 48


def wordmark_paths():
    x, parts = 0, []
    for i, ch in enumerate('ELISE'):
        w, d = LETTERS[ch]
        parts.append(f'<path transform="translate({x} 0)" d="{d}"/>')
        x += w + (TRACK if i < 4 else 0)
    return x, ''.join(parts)


WM_W, WM_PATHS = wordmark_paths()


def wordmark_group(col, tx=0, ty=0, s=1):
    return (f'<g transform="translate({tx} {ty}) scale({s})" fill="none" stroke="{col}" '
            f'stroke-width="{SW}" stroke-linejoin="miter" stroke-linecap="butt">{WM_PATHS}</g>')


def text_color(variant):
    return {'color': '#FFFFFF', 'color-onlight': INK, 'mono-light': '#FFFFFF', 'mono-dark': INK}[variant]


def svg(w, h, inner, defs='', title='ELISE'):
    d = f'<defs>{defs}</defs>' if defs else ''
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w:g} {h:g}" width="{w:g}" height="{h:g}" '
            f'role="img" aria-label="{title}"><title>{title}</title>{d}{inner}</svg>\n')


def write(name, content):
    with open(os.path.join(OUT, name), 'w') as f:
        f.write(content)


VARIANTS = ['color', 'color-onlight', 'mono-light', 'mono-dark']
for v in VARIANTS:
    # símbolo
    defs, g = symbol_group(v)
    write(f'elise-symbol-{v}.svg', svg(120, 120, g, defs))
    defs, g = symbol_group(v, 'small')
    write(f'elise-symbol-small-{v}.svg', svg(120, 120, g, defs))
    # horizontal: símbolo 120 · espacio 44 · ELISE alto 44
    cap = 40
    s = cap / 100
    defs, g = symbol_group(v)
    W = 120 + 36 + WM_W * s
    write(f'elise-horizontal-{v}.svg', svg(round(W, 2), 120, g + wordmark_group(text_color(v), 156, 60 - cap / 2, s), defs))
    # vertical: símbolo arriba, ELISE abajo
    cap = 34
    s = cap / 100
    ww = WM_W * s
    W = max(ww, 120)
    defs, g = symbol_group(v, tx=(W - 120) / 2)
    write(f'elise-vertical-{v}.svg', svg(round(W, 2), 120 + 30 + cap,
          g + wordmark_group(text_color(v), (W - ww) / 2, 150, s), defs))
    # solo palabra
    write(f'elise-wordmark-{v}.svg', svg(WM_W + 8, 108, wordmark_group(text_color(v), 4, 4, 1)))

# ── Íconos ──
BG = ('<linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">'
      '<stop offset="0" stop-color="#0B2630"/><stop offset="1" stop-color="#040C10"/></linearGradient>'
      '<radialGradient id="glow" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#22D3EE" stop-opacity=".22"/>'
      '<stop offset="1" stop-color="#22D3EE" stop-opacity="0"/></radialGradient>')


def app_icon(size=1024, rounded=True):
    r = size * 0.225 if rounded else 0
    sc = size * 0.6 / 120     # símbolo al 56 % → entra en la zona segura circular
    off = (size - 120 * sc) / 2
    defs, g = symbol_group('color', 'full', off, off, sc, uid='i')
    inner = (f'<rect width="{size}" height="{size}" rx="{r}" fill="url(#bg)"/>'
             f'<circle cx="{size/2}" cy="{size/2}" r="{size*0.42}" fill="url(#glow)"/>' + g)
    return svg(size, size, inner, BG + defs, 'ELISE')


write('../icons/app-icon.svg', app_icon(1024))
write('../icons/app-icon-square.svg', app_icon(1024, rounded=False))


def tile_icon(size, geom):
    """favicon: símbolo sobre baldosa oscura, se lee en pestañas claras y oscuras"""
    r = size * 0.22
    sc = size * (0.78 if geom == 'micro' else 0.72) / 120
    off = (size - 120 * sc) / 2
    top, bot, (cx, cy, cr) = symbol_shapes(GEOM[geom])
    inner = (f'<rect width="{size}" height="{size}" rx="{r:.2f}" fill="#06161C"/>'
             f'<g transform="translate({off:.3f} {off:.3f}) scale({sc:.4f})" fill="{CYAN}">'
             f'<path d="{top}"/><path d="{bot}"/><circle cx="{cx}" cy="{cy}" r="{cr}" fill="#B4F7FC"/></g>')
    return svg(size, size, inner)


write('../icons/favicon.svg', tile_icon(32, 'small'))
write('../icons/favicon-16.svg', tile_icon(16, 'micro'))
write('../icons/favicon-32.svg', tile_icon(32, 'small'))


def tray(size, col, geom):
    sc = size * 0.92 / 120
    off = (size - 120 * sc) / 2
    top, bot, (cx, cy, cr) = symbol_shapes(GEOM[geom])
    inner = (f'<g transform="translate({off:.3f} {off:.3f}) scale({sc:.4f})" fill="{col}">'
             f'<path d="{top}"/><path d="{bot}"/><circle cx="{cx}" cy="{cy}" r="{cr}"/></g>')
    return svg(size, size, inner)


write('../icons/tray-template.svg', tray(16, '#000000', 'micro'))
write('../icons/tray-light.svg', tray(16, '#FFFFFF', 'micro'))
write('../icons/tray-template-32.svg', tray(32, '#000000', 'small'))
write('../icons/tray-light-32.svg', tray(32, '#FFFFFF', 'small'))
print('ok', WM_W)
